/*
 * Tacx Fortius 1942 USB bicycle trainer driver
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA    
 *
 */
 

#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/usb/input.h>
#include <linux/time.h>
#include <linux/timer.h>

#define DRIVER_VERSION "v0.1.0"
#define DRIVER_DESC    "USB Tacx Fortius 1942 driver"
#define DRIVER_LICENSE "GPL"
#define DRIVER_AUTHOR  "Petr Blaha <blahapeta@gmail.com>, Michel Dagenais <michel.dagenais@polymtl.ca>"


/*Buffer sizes, do not decrease these values*/
/*read*/
#define BYTES_IN_DEVICE_1942	64
/*write*/
#define	BYTES_OUT_DEVICE_1942	12

/*USB endpoints*/
/*read*/
#define BULK_IN_INTERFACE_1942	82
/*write*/
#define BULK_OUT_INTERFACE_1942 02

#define DEFAULT_WHEEL_RESISTANCE 0
#define DEFAULT_CYCLIST_WEIGHT 0x50
#define TFOR_TIMEOUT 5000

static unsigned char tfor_open_message[] = 
	{0x02,0x00,0x00,0x00};
static unsigned char tfor_close_message[] = 
	{0x01,0x08,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x52,0x10,0x04};

struct usb_tfor {
	char name[128];
	char phys[64];
	struct usb_device *usbdev;
	struct input_dev *input;

	struct urb *irq;
	unsigned char *data;
	dma_addr_t idata_dma;

	struct urb *out;
	unsigned char *data_device;
	dma_addr_t odata_dma;

	struct timer_list timer;
	int wheel_resistance;
	unsigned int cyclist_weight;
};

static int usb_tfor_open(struct input_dev *dev)
{
	struct usb_tfor *tfor = input_get_drvdata(dev);

	tfor->data_device[0] =	tfor_open_message[0];
	tfor->data_device[1] =	tfor_open_message[1];
	tfor->data_device[2] =	tfor_open_message[2];
	tfor->data_device[3] =	tfor_open_message[3];
	tfor->out->transfer_buffer_length = 4;
	tfor->wheel_resistance = DEFAULT_WHEEL_RESISTANCE;
	tfor->cyclist_weight = DEFAULT_CYCLIST_WEIGHT;
	init_timer(&tfor->timer);
	usb_submit_urb(tfor->out, GFP_KERNEL);
	dbg("Fortius device opened weight %u wheel resistance %d",
			tfor->cyclist_weight, tfor->wheel_resistance);
	return 0;
}

static void usb_tfor_close(struct input_dev *dev)
{
	struct usb_tfor *tfor = input_get_drvdata(dev);
	int retval;
	int actual_length;

	del_timer_sync(&tfor->timer);
	usb_kill_urb(tfor->irq);
	usb_kill_urb(tfor->out);

	retval = usb_bulk_msg(tfor->usbdev, usb_sndbulkpipe(tfor->usbdev,
			BULK_OUT_INTERFACE_1942), tfor_close_message,
			sizeof(tfor_open_message), &actual_length, TFOR_TIMEOUT);
}

/*The input ubr is submitted after some timer based delay */
static void usb_tfor_submit_in_fn(unsigned long arg)
{
	struct usb_tfor *tfor = (struct usb_tfor *)arg;
	int status;

	status = usb_submit_urb(tfor->irq, GFP_ATOMIC);
	if (status)
		err("can't resubmit intr, %s-%s/input0, status %d",
				tfor->phys, tfor->usbdev->devpath, status);
}

/*The output ubr completion*/
static void usb_tfor_out(struct urb *urb)
{	struct usb_tfor *tfor = urb->context;

	switch (urb->status) {
	case 0:
		/*success*/
		break;
	case -ECONNRESET:
	case -ENOENT:
	case -ESHUTDOWN:
		/*this urb is terminated*/
		dbg("%s - urb shutting down with status: %d", __func__,
				urb->status);
		return;
	default:
		dbg("%s - nonzero urb status received: %d", __func__, urb->status);
	}

	/*give time to the trainer to prepare its data before reading*/
	tfor->timer.expires = jiffies + 70 * HZ / 1000;
	tfor->timer.function = usb_tfor_submit_in_fn;
	tfor->timer.data = (unsigned long)tfor;
	add_timer(&tfor->timer);
}

/*The input ubr completion*/
static void usb_tfor_irq(struct urb *urb)
{
	struct usb_tfor *tfor = urb->context;
	unsigned char *data = tfor->data;
	struct input_dev *dev = tfor->input;
	int pedal_sensor = 0;
	int status;
	int value;

	switch (urb->status) {
	case 0:
		/*success*/
	 	break;
	case -ECONNRESET:
	case -ENOENT:
	case -ESHUTDOWN:
		/*this urb is terminated*/
		dbg("%s - urb shutting down with status: %d", __func__,
				urb->status);
		return;
	default:
		dbg("%s - nonzero urb status received: %d", __func__,
				urb->status);
		goto resubmit;
	}

	if (urb->actual_length >= 24) {
		/*Byte 13 contains the handlebar controller buttons*/
		input_report_key(dev, BTN_RIGHT, data[13] & 0x01);
		input_report_key(dev, BTN_BACK, data[13] & 0x02);
		input_report_key(dev, BTN_FORWARD, data[13] & 0x04);
		input_report_key(dev, BTN_LEFT, data[13] & 0x08);

		/*Steering, bytes 18 and 19*/
		value = data[18] | (data[19] << 8);
		input_report_abs(dev, ABS_WHEEL, value);
	}
	if (urb->actual_length >= 48) {
		/*Distance, bytes 28, 29, 30, 31*/
        	value = data[28] | (data[29] << 8) | (data[30] << 16) | 
				(data[31] << 24);
		input_report_abs(dev, ABS_DISTANCE, value);
		/*Speed, bytes 32, 33*/
		value = data[32] | (data[33] << 8);
		input_report_abs(dev, ABS_GAS, value);
		/*Power output of cyclist (force on wheel), bytes 38, 39*/
		value = (__s16)(data[38] | (data[39] << 8));
		input_report_abs(dev, ABS_VOLUME, value);
		/*Pedal sensor, byte 42*/
		pedal_sensor = data[42];
		input_report_key(dev, BTN_0, data[42]);
		/*Pedaling cadence, bytes 44, 45*/
		value = data[44] | (data[45] << 8);
		input_report_abs(dev, ABS_MISC, value);
		/*Cyclist active, byte 46*/
		input_report_key(dev, BTN_1, data[46] & 0x02);
	}
	/*event to mark end of this input sequence*/
	input_sync(dev);

resubmit:
	/*Immediately send the next output ubr*/
	/*constant*/
	tfor->data_device[0] =	0x01;
	/*constant*/
	tfor->data_device[1] =	0x08;
	/*constant*/
	tfor->data_device[2] =	0x01;
	/*constant*/
	tfor->data_device[3] =	0x00;
	/*brake_bits*/
	tfor->data_device[4] =	tfor->wheel_resistance & 0xff;
	/*brake_bits*/
	tfor->data_device[5] =	(tfor->wheel_resistance >> 8) & 0xff;
	/*echo of the pedal sensor value read*/
	tfor->data_device[6] =	pedal_sensor;
	/*constant*/
	tfor->data_device[7] =	0x00;
	/*constant*/
	tfor->data_device[8] =	0x02;
	/*cyclist weight*/
	tfor->data_device[9] =	tfor->cyclist_weight;
	/*constant*/
	tfor->data_device[10] =	0x10;
	/*constant*/
	tfor->data_device[11] =	0x04;
	tfor->out->transfer_buffer_length = BYTES_OUT_DEVICE_1942;

	status = usb_submit_urb(tfor->out, GFP_ATOMIC);
	if (status)
		err("%s - usb_submit_urb failed with result %d",__func__, status);
}

static int tfor_playback(struct input_dev *dev, int effect_id, int value)
{
	return 0;
}

static int tfor_upload_effect(struct input_dev *dev, struct ff_effect *effect,
		struct ff_effect *old)
{
	struct usb_tfor *tfor = input_get_drvdata(dev);

	if (effect->type != FF_FRICTION)
		return -EINVAL;

	if(effect->u.condition[0].right_coeff < -0x0cb3 || 
			effect->u.condition[0].right_coeff > 0x32cb)
		return -EINVAL;

	if(effect->u.condition[0].right_saturation < 50 || 
			effect->u.condition[0].right_saturation > 120)
		return -EINVAL;

	tfor->wheel_resistance = effect->u.condition[0].right_coeff;
	tfor->cyclist_weight = effect->u.condition[0].right_saturation;
	return 0;
}

static int tfor_erase_effect(struct input_dev *dev, int effect_id)
{
	return 0;
}

static void __devexit __devexit_tfor(struct usb_interface *intf)
{
	struct usb_tfor *tfor = usb_get_intfdata(intf);

	del_timer_sync(&tfor->timer);
	usb_set_intfdata(intf, NULL);
	input_unregister_device(tfor->input);
	usb_free_urb(tfor->out);
	usb_free_urb(tfor->irq);
	usb_buffer_free(interface_to_usbdev(intf), 10, tfor->data_device,
			tfor->odata_dma);
	usb_buffer_free(interface_to_usbdev(intf), 10, tfor->data,
			tfor->idata_dma);
	kfree(tfor);
}

static int __devinit tfor_probe(struct usb_interface *intf,
		const struct usb_device_id *id)
{
	struct usb_device *dev = interface_to_usbdev(intf);
	struct usb_tfor *tfor;
	struct input_dev *input_dev;
	struct ff_device *ff;
	int retval;

	tfor = kzalloc(sizeof(struct usb_tfor), GFP_KERNEL);
	if (!tfor) {
		retval = -ENOMEM;
		goto fail1;
	}

	input_dev = input_allocate_device();
	if (!input_dev) {
		retval = -ENOMEM;
		goto fail2;
	}

	tfor->data = usb_buffer_alloc(dev, BYTES_IN_DEVICE_1942, GFP_KERNEL,
			&tfor->idata_dma);
	if (!tfor->data) {
		retval = -ENOMEM;
		goto fail3;
	}

	tfor->data_device = usb_buffer_alloc(dev, BYTES_OUT_DEVICE_1942,
			GFP_KERNEL, &tfor->odata_dma);
	if (!tfor->data_device) {
		retval = -ENOMEM;
		goto fail4;
	}

	tfor->irq = usb_alloc_urb(0, GFP_KERNEL);
	if (!tfor->irq) {
		retval = -ENOMEM;
		goto fail5;
	}

	tfor->out = usb_alloc_urb(0, GFP_KERNEL);
	if (!tfor->out) {
		retval = -ENOMEM;
		goto fail6;
	}

	tfor->usbdev = dev;
	tfor->input = input_dev;

	usb_make_path(dev, tfor->phys, sizeof(tfor->phys));
	strlcat(tfor->phys, "/input0", sizeof(tfor->phys));

	input_dev->name = tfor->name;
	input_dev->phys = tfor->phys;
	usb_to_input_id(dev, &input_dev->id);
	input_dev->dev.parent = &intf->dev;
	input_set_drvdata(input_dev, tfor);
	tfor->irq->dev = tfor->usbdev;
	tfor->out->dev = tfor->usbdev;
	input_dev->open = usb_tfor_open;
	input_dev->close = usb_tfor_close;
	input_dev->evbit[0] = BIT_MASK(EV_ABS) | BIT_MASK(EV_KEY);
	/*handlebar*/
	input_set_abs_params(input_dev, ABS_WHEEL, 0, 0, 0, 0);
	/*distance*/
	input_set_abs_params(input_dev, ABS_DISTANCE, 0, 0, 0, 0);
	/*watts*/
	input_set_abs_params(input_dev, ABS_VOLUME, 0, 0, 0, 0);
	/*speed*/
	input_set_abs_params(input_dev, ABS_GAS, 0, 0, 0, 0);
	/*pedaling cadence*/
	input_set_abs_params(input_dev, ABS_MISC, 0, 0, 0, 0);
	/*enter button*/
	set_bit(BTN_RIGHT, input_dev->keybit);
	/*down button*/
	set_bit(BTN_BACK, input_dev->keybit);
	/*up button*/
	set_bit(BTN_FORWARD, input_dev->keybit);
	/*cancel button*/
	set_bit(BTN_LEFT, input_dev->keybit);
	/*pedal sensor*/
	set_bit(BTN_0, input_dev->keybit);
	/*cyclist active signal*/
	set_bit(BTN_1, input_dev->keybit);
	/*wheel resistance as force feedback */
        input_set_capability(input_dev, EV_FF, FF_FRICTION);

	retval = input_ff_create(input_dev, 1);
	if (retval)
		goto fail;

	ff = input_dev->ff;
	ff->upload = tfor_upload_effect;
	ff->erase = tfor_erase_effect;
	ff->playback = tfor_playback;

	usb_fill_bulk_urb(tfor->irq, dev, usb_rcvbulkpipe(dev,
			BULK_IN_INTERFACE_1942), tfor->data, BYTES_IN_DEVICE_1942,
			usb_tfor_irq, tfor);
	tfor->irq->transfer_dma = tfor->idata_dma;
	tfor->irq->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;

	usb_fill_bulk_urb(tfor->out, dev, usb_sndbulkpipe(dev,
			BULK_OUT_INTERFACE_1942), tfor->data_device,
			 BYTES_OUT_DEVICE_1942, usb_tfor_out, tfor);
	tfor->out->transfer_dma = tfor->odata_dma;
	tfor->out->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;

	retval = input_register_device(tfor->input);
	if (retval)
		goto fail;

	usb_set_intfdata(intf, tfor);
	return 0;

 fail:	usb_free_urb(tfor->out);
 fail6: usb_free_urb(tfor->irq);
 fail5:	usb_buffer_free(dev, BYTES_OUT_DEVICE_1942, tfor->data_device,
			tfor->odata_dma);
 fail4:	usb_buffer_free(dev, BYTES_IN_DEVICE_1942, tfor->data, tfor->idata_dma);
 fail3:	input_free_device(input_dev);
 fail2:	kfree(tfor);
 fail1:	return retval;
}

static int tfor_resume(struct usb_interface *intf)
{
	return 0;
}

static int tfor_suspend(struct usb_interface *intf, pm_message_t message)
{
	return 0;
}

static struct usb_device_id tfor_ids[] = {
	{ USB_DEVICE(0x3561, 0x1942), .driver_info = 0 },
	{ }
};

MODULE_DEVICE_TABLE (usb, tfor_ids);

static struct usb_driver tfor_driver = {
	.name =	"fortius_1942",
	.probe = tfor_probe,
	.disconnect = __devexit_tfor,
	.id_table = tfor_ids,
	.suspend = tfor_suspend,
	.resume = tfor_resume,
};

static int __init tfor_init(void)
{
	int retval;

	retval = usb_register(&tfor_driver);
	return retval;
}

static void __exit tfor_exit(void)
{
	usb_deregister(&tfor_driver);
}

module_init(tfor_init);
module_exit(tfor_exit);

MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE(DRIVER_LICENSE);

