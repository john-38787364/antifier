
/*
  This program is an example of how to use the fortius_1942 driver
  It may also be used to calibrate the conversion factors between the
  raw data returned by the fortius unit and the usual values (distance
  in km, speed in km/h, cadence in strokes per minute, power in watts).
  The coefficients used here for the speed and distance look pretty reliable.
  The cadence is highly variable and should be averaged. The power is harder 
  to calibrate.

  You can increase/decrease the wheel resistance with the forward and 
  backward arrows on the handlebar device. You can quit the test program with the
  cancel button on the handlebar device.
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <linux/input.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

void print_event(struct input_event e)
{
	printf("Event type %hu, code %hu, value %d, time %lu.%06lu\n", e.type, e.code, e.value, e.time.tv_sec, e.time.tv_usec);
}

void print_field(char *name, int value)
{
	printf("%s = %5d, ", name, value);
}

void print_float_field(char *name, float value)
{
	printf("%s = % 7.2f, ", name, value);
}

void usage(char *name)
{
	fprintf(stderr,"%s: [--device path --weight kg --wheel slope]\n", name);
}

/*options such as which fields to print by default*/
static int blocking = 1;
static int print_details = 0;
static int null_event = 0;
static int enter_event = 0;
static int cancel_event = 0;
static int up_event = 0;
static int down_event = 0;
static int pedal_event = 1;
static int status_event = 0;
static int speed_event = 1;
static int distance_event = 1;
static int cadence_event = 1;
static int wheel_event = 1;
static int power_event = 1;
static int friction_event = 1;
static char *bike_device = "/dev/input/by-id/usb-Tacx_bv_Tacx_Fortius-event-joystick";
static int wheel_resistance = 0;
static int cyclist_weight = 0x52;
static unsigned display_period = 500;
static unsigned cadence_period = 60000;
 
void parse_options(int argc, char **argv)
{
	int i;

	for (i = 1; i < argc; i++) {
		if (strcmp(argv[i],"--blocking") == 0) {
			blocking = !blocking;
		} else if (strcmp(argv[i],"--print_details") == 0) {
			print_details = !print_details;
		} else if (strcmp(argv[i],"--null_event") == 0) {
			null_event = !null_event;
		} else if (strcmp(argv[i],"--enter_event") == 0) {
			enter_event = !enter_event;
		} else if (strcmp(argv[i],"--cancel_event") == 0) {
			cancel_event = !cancel_event;
		} else if (strcmp(argv[i],"--up_event") == 0) {
			up_event = !up_event;
		} else if (strcmp(argv[i],"--down_event") == 0) {
			down_event = !down_event;
		} else if (strcmp(argv[i],"--pedal_event") == 0) {
			pedal_event = !pedal_event;
		} else if (strcmp(argv[i],"--status_event") == 0) {
			status_event = !status_event;
		} else if (strcmp(argv[i],"--speed_event") == 0) {
			speed_event = !speed_event;
		} else if (strcmp(argv[i],"--distance_event") == 0) {
			distance_event = !distance_event;
		} else if (strcmp(argv[i],"--cadence_event") == 0) {
			cadence_event = !cadence_event;
		} else if (strcmp(argv[i],"--wheel_event") == 0) {
			wheel_event = !wheel_event;
		} else if (strcmp(argv[i],"--power_event") == 0) {
			power_event = !power_event;
		} else if (strcmp(argv[i],"--friction_event") == 0) {
			friction_event = !friction_event;
		} else if (strcmp(argv[i],"--wheel") == 0) {
			i++;
			if (i >= argc) {
				fprintf(stderr,"%s: missing argument for %s\n", 
					argv[0], argv[i-1]);
				exit(1);
			}
			wheel_resistance = atoi(argv[i]) * 13003.0 / 20.0;
		} else if (strcmp(argv[i],"--weight") == 0) {
			i++;
			if (i >= argc) {
				fprintf(stderr,"%s: missing argument for %s\n", 
					argv[0], argv[i-1]);
				exit(1);
			}
			cyclist_weight = atoi(argv[i]);
		} else if (strcmp(argv[i],"--display-period") == 0) {
			i++;
			if (i >= argc) {
				fprintf(stderr,"%s: missing argument for %s\n", 
					argv[0], argv[i-1]);
				exit(1);
			}
			display_period = atoi(argv[i]);
		} else if (strcmp(argv[i],"--cadence-period") == 0) {
			i++;
			if (i >= argc) {
				fprintf(stderr,"%s: missing argument for %s\n", 
					argv[0], argv[i-1]);
				exit(1);
			}
			cadence_period = atoi(argv[i]);
		} else if (strcmp(argv[i],"--device") == 0) {
			i++;
			if (i >= argc) {
				fprintf(stderr,"%s: missing argument for %s\n", 
					argv[0], argv[i-1]);
				exit(1);
			}
			bike_device = argv[i];
		} else if (strcmp(argv[i],"--help") == 0) {
			usage(argv[0]);
			exit(0);
		} else {
			usage(argv[0]);
			exit(1);
		}
	}
}

int main(int argc, char **argv)
{
	int retval;
	int fd;
        struct input_event e;
	struct timespec t1, t2;
	struct ff_effect effect;

	/*values read or computed*/
	float raw_speed = 0;
	float speed = 0;
	float speed_avg = 0;
	float speed_sum = 0;
	float speed_computed = 0;
	float distance = 0;
	float last_distance = 0;
	float distance_origin = 0.0;
	float cadence = 0;
	float cadence_avg = 0;
	float cadence_sum = 0;
	float cadence_computed = 0.0;
	int cadence_number = 0;
	int last_cadence_number = 0;
	int delta_pedal_sensor = 0;
	int last_pedal_sensor = 0;
	float wheel = 0;
	float force = 0;
	float power = 0;
	int event_time = 0;
	int next_time = 0;
	int delta_time = 0;
	int delta_cadence_time = 0;
	int last_cadence_time = 0;
	int next_cadence_time = 0;
	int last_cadence_event_time = 0;
	int last_speed_event_time = 0;

	/*count the different events*/
	int nb_enter = 0;
	int nb_cancel = 0;
	int nb_up = 0;
	int nb_down = 0;
	int nb_pedal_sensor = 0;
	int nb_status = 0;
	int nb_speed = 0;
	int nb_distance = 0;
	int nb_cadence = 0;
	int nb_wheel = 0;
	int nb_power = 0;
	int nb_null_event = 0;

	parse_options(argc, argv);

	/*open the bicycle at its default location*/
	if(blocking) 
		fd = open (bike_device, O_RDWR);
	else
		fd = open (bike_device, O_NONBLOCK | O_RDWR);

	if (fd < 0) {
		fprintf(stderr, "%s: cannot open device %s\n", argv[0],
			bike_device);
		exit(1);
	}

	/*set the default wheel resistance and cyclist weight*/
	effect.type = FF_FRICTION;
	effect.id = -1;
	effect.u.condition[0].right_coeff = wheel_resistance;
	effect.u.condition[0].right_saturation = cyclist_weight;
	retval = ioctl(fd, EVIOCSFF, &effect);

	if (retval < 0) {
		fprintf(stderr, "%s: cannot set wheel resistance\n", argv[0]);
	}

	/*repeatedly read input events*/
	for(;;) {
		retval = read (fd, &e, sizeof(struct input_event));

		if(retval <= 0) {
			if (errno != EAGAIN) {
        	        	fprintf(stderr,"Error reading %d\n", errno);
        	        }
			/*no event ready, wait a little while to avoid spinning*/
			if(!blocking) {
				t1.tv_sec = 0;
				t1.tv_nsec = 20000000;
				retval = nanosleep(&t1, &t2);
				continue;
			}
		}

		if(print_details) print_event(e);

		/*have time in miliseconds but truncate most significant digits
		  to avoid overflow*/
		event_time = (e.time.tv_sec % 100000) * 1000 + 
			e.time.tv_usec / 1000;

		if(e.type == EV_KEY && (!e.value)) {
			/*key released do nothing*/
		} else if(e.type == EV_KEY) {
			/*key pressed*/
			if(e.code == BTN_RIGHT) {
				/*set the origin to ease calibration*/
				distance_origin = distance;
				nb_enter++;
			} else if(e.code == BTN_BACK) {
				nb_down++;
				/*diminish the wheel resistance*/
				wheel_resistance -= 650;
				effect.u.condition[0].right_coeff =
					wheel_resistance;
				retval = ioctl(fd, EVIOCSFF, &effect);
				if (retval < 0) {
					fprintf(stderr, "%s: cannot set wheel "
						"resistance in BTN back\n", 
						argv[0]);
				}
			} else if(e.code == BTN_FORWARD) {
				nb_up++;
				/*augment the wheel resistance*/
				wheel_resistance += 650;
				effect.u.condition[0].right_coeff = 						wheel_resistance;
				retval = ioctl(fd, EVIOCSFF, &effect);
				if (retval < 0) {
					fprintf(stderr, "%s: cannot set wheel " 						"resistance in BTN forward\n", 
						argv[0]);
				}
			} else if(e.code == BTN_LEFT) {
				nb_cancel++;
				/*stop the program*/
				break;
			} else if(e.code == BTN_0) {
				nb_pedal_sensor++;
			} else if(e.code == BTN_1) {
				nb_status++;
			} else {
				print_event(e);
			}
		} else if(e.type == EV_ABS) {
			/*range values such as speed and distance*/
			if(e.code == ABS_WHEEL) {
				/*center around 0*/
				wheel = e.value - 0x3b9;
				nb_wheel++;
			} else if(e.code == ABS_DISTANCE) {
				/*convert to km*/
				distance = (float)e.value / 15654.0;
				nb_distance++;
			} else if(e.code == ABS_GAS) {
				/*convert to km/h, 40.4 for 40*/
				raw_speed = (float)e.value;
				speed = raw_speed / 282.2;
				delta_time = event_time - last_speed_event_time;
				last_speed_event_time = event_time;
				speed_sum += speed * delta_time;
				nb_speed++;
			} else if(e.code == ABS_VOLUME) {
				/*looking for watts*/
				force = (float)e.value;
				power =  force * raw_speed * 0.000008052;
				nb_power++;
			} else if(e.code == ABS_MISC) {
				/*strokes per minute*/
				cadence = (float)e.value / 48.0;
				delta_time = event_time - last_cadence_event_time;
				last_cadence_event_time = event_time;
				cadence_sum += cadence * delta_time;
				nb_cadence++;
				cadence_number++;
			} else {
				print_event(e);
			}
		} else if(e.type == 0) {
			/*sync event after each sequence of related values*/
			nb_null_event++;
		} else {
			/*there should not be unknown events*/
			print_event(e);
		}

		/*every minute (cadence period) or so recompute derived values
		  such as cadence from pedal sensor and speed from distance/time.
		  This helps for calibrating values one against another.*/
		if (event_time >= next_cadence_time) {
			delta_cadence_time = event_time - last_cadence_time;

			/*compute the cadence average and (pedal strokes / time)*/
			delta_time = event_time - last_cadence_event_time;
			cadence_sum += cadence * delta_time;
			last_cadence_event_time = event_time;

			cadence_avg = cadence_sum / delta_cadence_time;
			last_cadence_number = cadence_number;
			cadence_number = 0;
			cadence_sum = 0.0;
			delta_pedal_sensor = nb_pedal_sensor - last_pedal_sensor;
			cadence_computed = delta_pedal_sensor * 
				(60000.0 / delta_cadence_time);
			last_pedal_sensor = nb_pedal_sensor;

			/*compute the speed average and (distance / time)*/
			delta_time = event_time - last_speed_event_time;
			speed_sum += speed * delta_time;
			last_speed_event_time = event_time;

			speed_avg = speed_sum / delta_cadence_time;
			speed_sum = 0;
			speed_computed = (distance - last_distance) *
				(3600000.0 / delta_cadence_time);
			last_distance = distance;

			last_cadence_time = event_time;
			next_cadence_time = event_time + cadence_period;
		}

		/*at regular interval (200ms) print the values read and computed*/
		if (event_time >= next_time) {
			next_time = event_time + display_period;
			if (null_event) 
				print_field("null", nb_null_event);
			if (enter_event) 
				print_field("enter", nb_enter);
			if (cancel_event)
				print_field("cancel", nb_cancel);
			if (up_event)
				print_field("up", nb_up);
			if (down_event)
				print_field("down", nb_down);
			if (pedal_event)
				print_field("pedal", nb_pedal_sensor);
			if (status_event)
				print_field("status", nb_status);
			if (speed_event) {
				printf("speed %6.1f %6.1f %6.1f, ", 
					speed, speed_avg, speed_computed);
			}
			if (distance_event) {
				print_float_field("distance", 
					distance - distance_origin);
			}
			if (cadence_event) {
				printf("cadence %6.1f %6.1f %6.1f, %4d %4d, ",
					cadence, cadence_avg, cadence_computed,
					delta_pedal_sensor, last_cadence_number);
			}
			if (wheel_event)
				print_float_field("wheel", wheel);
			if (power_event) {
				print_float_field("force", force);
				print_float_field("power", power);
			}
			if (friction_event) 
				print_float_field("resistance", wheel_resistance);
			printf("\n");
			fflush(stdout);
		} 		
	}
	printf("\n");
	print_field("null", nb_null_event);
	print_field("enter", nb_enter);
	print_field("cancel", nb_cancel);
	print_field("up", nb_up);
	print_field("down", nb_down);
	print_field("pedal", nb_pedal_sensor);
	print_field("status", nb_status);
	printf("\n");
	print_field("speed", nb_speed);
	print_field("distance", nb_distance);
	print_field("cadence", nb_cadence);
	print_field("wheel", nb_wheel);
	print_field("power", nb_power);
	printf("\n");
	close(fd);
	return 0;
}

