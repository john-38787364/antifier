#! /bin/sh

# Simple script to extract the firmware file from the Fortius CD

# The CD is expected to be mounted on /media/cdrom

echo "\nExtract_cd: Searching for Tacx System Test.msi on /media/cdrom*"
ARCHIVE_FILE=`ls /media/cdrom*/FortiusInstall/support/TacxSystemTest/Tacx\ System\ Test.msi | head -n 1`

if test -n "$ARCHIVE_FILE" -a -f "$ARCHIVE_FILE"; then
  echo "\nExtract_cd: file found at: $ARCHIVE_FILE"
else
  echo "\nExtract_cd: file Tacx System Test.msi not found"
  exit 1
fi

# Program cabextract does not accept a pipe input, create a temporary file
TEMP_FILE=`mktemp`
if test -n "$TEMP_FILE"; then
  echo "\nExtract: decompress and extract to temporary file $TEMP_FILE"
else
  echo "\nExtract_cd: cannot create temporary file $TEMP_FILE"
  exit 1
fi

# Decompress and extract the relevant component (CAB file) from the MSI file
7z e -so "$ARCHIVE_FILE" _EC9F4244E86648C58495D9F11FB8BA92 >$TEMP_FILE

# Extract the firmware file from the cabinet file
echo "\nExtract_cd: extract FortiusSWPID1942Renum.hex from temporary file $TEMP_FILE"
cabextract -p -s -F_E155F1FD431C4B4FB9177EF9F71E0A09 $TEMP_FILE >FortiusSWPID1942Renum.hex
rm $TEMP_FILE

# We have the firmware file, check if it matches the tested version with md5sum
HEX_FILE_SUM=`md5sum FortiusSWPID1942Renum.hex | sed -e "s/ .*//"`
if test -n FortiusSWPID1942Renum.hex; then
  if test "$HEX_FILE_SUM" = "432c1a4fc03dd96f51f2607e46c5f25f"; then
    echo "\nExtract_cd: firmware file FortiusSWPID1942Renum.hex extracted successfully"
    echo "and appears identical (same checksum) to the tested version"
  else
    echo "\nExtract_cd: firmware file FortiusSWPID1942Renum.hex extracted"
    echo "but differs (different checksum) from tested version"
    echo "may be a different version, untested with this driver"
    echo "or something failed"
  fi
else
  echo "Extract_cd: firmware file FortiusSWPID1942Renum.hex could not be extracted"
fi

